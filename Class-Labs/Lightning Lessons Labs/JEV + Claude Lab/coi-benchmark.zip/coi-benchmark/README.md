# COI Benchmark

A Claude Code skill scaffold for batch-evaluating Certificates of Insurance (COIs) using Claude or Jev and displaying only an inline Efficiency Dashboard.

## Folder structure

- `.claude/skills/coi-benchmark/SKILL.md` — workflow instructions
- `coi-documents/` — place COI PDF files here
- `checklist.pdf` — place your compliance checklist in the project root
- `results/` — run data is saved here

## Use

1. Copy COI PDF files into `coi-documents/`.
2. Add the compliance checklist as `checklist.pdf`.
3. Open this project folder in Claude Code.
4. Invoke `/coi-benchmark`.
5. Choose Claude, Jev, or Both when prompted.

## Setup notes

- This ZIP is a starter scaffold; it does not include COI documents, a checklist, or API credentials.
- Jev use requires a working Typesafe setup and valid API credentials.
- Do not commit private COIs, the checklist, credentials, or run results to a public repository.
- Inline dashboard rendering depends on the active Claude Code interface and its capabilities.
