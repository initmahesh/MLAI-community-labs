---
name: coi-benchmark
description: Batch-evaluate Certificates of Insurance (COIs) using Claude or Jev and display only an inline Efficiency Dashboard comparing latency, cost, and throughput.
---

# COI Batch Evaluation and Efficiency Benchmark

## Objective

Evaluate any number of Certificates of Insurance (COIs) against a shared compliance checklist using either Claude or Jev.

The primary purpose is to compare the efficiency of both evaluators.

**Mandatory output rule: Display ONLY the Efficiency Dashboard as a visualization.**

Never display compliance matrices, stacked compliance charts, PASS/FAIL charts, accuracy dashboards, or additional visualizations.

## 1. Discover Input Files

1. Locate the `coi-documents/` directory in the current project.
2. Discover all supported COI PDF files in that directory.
3. Locate the compliance checklist, preferably `checklist.csv` in the project root.
4. Count the discovered COIs and identify their filenames.
5. If the directory is empty, the checklist is missing, or a document cannot be read, explain the issue and ask the user to resolve it.
6. Never silently skip unreadable files or treat missing documents as successful evaluations.

Support any number of COIs. Do not hardcode filenames or assume there will be only three documents.

## 2. Ask the User to Choose an Evaluator

Before processing documents, ask:

"Which evaluator would you like to use?

1. Claude — Claude evaluates every requirement directly.
2. Jev — Jev makes structured compliance decisions.
3. Both — Run both evaluators on the same documents and compare their efficiency."

Wait for the user's answer before proceeding.

If the user chooses Claude or Jev, run only the selected evaluator initially.

After displaying its Efficiency Dashboard, ask whether the user wants to run the other evaluator against the same COIs and checklist.

If the user chooses Both, run both evaluations and display one final comparison dashboard.

## 3. Evaluation Rules

Use the same checklist and requirement definitions for both evaluators.

For each COI requirement, assign exactly one status:

- PASS: Explicit evidence demonstrates that the requirement is satisfied.
- FAIL: Explicit evidence demonstrates that the requirement is not satisfied.
- NOT_EVIDENCED: Available evidence does not establish whether the requirement is satisfied.

Use only evidence from the COI. Do not invent, infer, or silently change findings.

Retain requirement-level results internally so that evaluations can be validated and compared if needed.

Do not display the compliance matrix or individual requirement results as part of the normal dashboard output.

If the user explicitly requests detailed findings, provide them separately from the standard Efficiency Dashboard workflow.

## 4. Claude Evaluation Mode

When Claude is selected:

1. Read the checklist and all discovered COIs.
2. Evaluate every requirement using Claude.
3. Record the results internally.
4. Measure total evaluation wall-clock time.
5. Capture available model usage, token counts, and actual cost information.
6. Record processing errors and incomplete documents.

Use actual measurement data wherever available.

Do not invent latency, cost, token usage, or throughput values.

Display only the Efficiency Dashboard after the evaluation finishes.

If a metric cannot be measured, display `N/A`.

## 5. Jev Evaluation Mode

When Jev is selected:

1. Read the official Typesafe documentation at `https://docs.typesafe.ai/llms.txt`.
2. Follow the documented API endpoint, authentication, request format, and response format.
3. Use the configured Typesafe integration or installed Typesafe skill.
4. Confirm that Jev is actually invoked for the evaluation.
5. Submit the permitted checklist requirements and relevant COI evidence to Jev for structured decisions.
6. Preserve the returned decisions and confidence information when available.
7. Validate returned statuses against the allowed options.
8. Record latency, available cost and token metadata, and processing errors.

Claude may prepare inputs, organize responses, and render the dashboard, but must not silently replace or alter Jev's decisions.

If Jev returns an invalid response, an error, or a missing decision, report the failure accurately. Do not fabricate a result or silently substitute a Claude decision.

### Security

Never expose API keys or store secrets in shared files.

Ask the user for permission before transmitting private or sensitive document content to the external API.

Use environment variables or an appropriate secure credential store for API credentials.

Display only the Efficiency Dashboard after the evaluation finishes.

## 6. Batch Processing

Process all discovered COIs using the selected evaluator.

For each run:

1. Evaluate every readable COI against the same checklist.
2. Record the number of COIs successfully processed.
3. Record start time, end time, and total wall-clock duration.
4. Capture available request-level latency and usage metadata.
5. Record actual costs where available.
6. Track failed, incomplete, or unreadable documents.
7. Validate the completed results.

Use sequential processing or controlled concurrency that respects the API's documented rate limits.

Do not assume that processing more documents automatically makes Jev faster or cheaper.

Measure performance for the actual workload.

If a run is incomplete, identify that limitation and do not present the run as directly equivalent to a completed run.

## 7. Efficiency Metrics

The dashboard must contain exactly three metrics.

### Latency

Show actual evaluation time.

Where available, distinguish:
- Total batch wall-clock time.
- Individual request latency or average request latency.

For the main comparison, use total batch wall-clock time for the complete workload.

### Cost

Show the actual total cost for the evaluation run.

Use actual billing or usage metadata where available.

If exact cost is unavailable, display `N/A`. Do not substitute an unsupported estimate.

If an estimate is explicitly available and useful, label it clearly as **Estimated**, separate from measured values.

### Throughput

Calculate throughput using:

Throughput = Number of successfully processed COIs / Total batch wall-clock time in minutes.

Use the same definition for Claude and Jev.

Display the value in COIs per minute.

Include incomplete processing in the run notes if it affects the fairness of the comparison. Never count a failed COI as successfully processed.

## 8. Generate the Efficiency Dashboard

Display ONLY one inline visualization titled:

**Efficiency Dashboard**

The dashboard must contain exactly these three metrics:

- Latency
- Cost
- Throughput

### Visual design

- Claude = RED.
- Jev = GREEN.
- Use horizontal comparison bars.
- Show exact values and units alongside each bar.
- Lower latency is better.
- Lower cost is better.
- Higher throughput is better.
- Use consistent scales for comparable metrics.
- Clearly label measured and estimated values.
- Show `N/A` when a value is unavailable.
- Use a dark, compact, presentation-ready layout.
- Keep text and labels readable for screen sharing and demonstrations.

### Claude-only run

Display Claude's measurements.

Do not invent Jev measurements or show a fabricated comparison.

### Jev-only run

Display Jev's measurements.

Do not invent Claude measurements or show a fabricated comparison.

### Both evaluators completed

Display Claude and Jev side by side in the same Efficiency Dashboard.

Highlight Jev's advantage only when supported by actual measurements.

If Claude performs better for a metric, show that honestly.

### Output restrictions

The standard evaluation output must contain ONLY the Efficiency Dashboard as a visualization.

Do not display:

- Compliance matrices.
- Stacked compliance charts.
- PASS/FAIL/NOT_EVIDENCED charts.
- Accuracy or agreement dashboards.
- Overall scores or rankings.
- Additional charts.
- HTML pages or downloadable reports.
- An Artifact or separate dashboard file.

Use native inline chart rendering supported by the current Claude Code environment. If a requested visualization cannot be rendered, explain the limitation briefly rather than fabricating a chart or creating an unrequested file.

## 9. Offer the Second Evaluation

After displaying the selected evaluator's Efficiency Dashboard, ask:

"Would you like to run the other evaluator on the same COIs and checklist for a performance comparison?"

If the user declines, stop the workflow.

If the user agrees:

1. Run the other evaluator independently.
2. Use exactly the same COIs and checklist.
3. Preserve the first evaluator's results and measurements.
4. Use the same measurement definitions for both runs.
5. Generate the final Efficiency Dashboard comparing both evaluators.

Do not overwrite earlier results.

## 10. Final Claude vs Jev Comparison

When both runs are complete, display a single inline visualization titled:

**Efficiency Dashboard — Claude vs Jev**

Include exactly three metrics:

1. Latency.
2. Cost.
3. Throughput.

### Comparison requirements

- Claude bars must be red.
- Jev bars must be green.
- Display exact measured values and units.
- Clearly label estimated or unavailable values.
- Use the same workload and measurement definitions.
- Highlight Jev's advantage only when supported by measured results.
- Do not claim that Jev is always faster, cheaper, or better.
- Do not claim greater accuracy based on speed or cost.

If the workload, model configuration, or measurement conditions differ materially, explain the limitation briefly.

Do not add compliance charts, tables, scores, rankings, or additional visualizations.

The dashboard must be the only visualization in the final comparison output.

## 11. Save Run Data

Save reproducible run data under a new directory inside `results/`, without overwriting previous runs.

Example structure:

results/
- run-001/
  - claude-results.json
  - run-metadata.json
- run-002/
  - jev-results.json
  - run-metadata.json
- comparison/
  - comparison.json

Create only files relevant to the completed workflow.

Store:
- Run identifier.
- Input filenames and file hashes when feasible.
- Checklist identity or version.
- Evaluator and model identifiers.
- Start and end timestamps.
- Total elapsed time.
- Number of successfully processed COIs.
- Available latency, token usage, and cost measurements.
- Throughput.
- Errors and incomplete processing.

Never store API keys, secrets, or unnecessary sensitive document contents.

Do not create an HTML dashboard, chart image, or downloadable report.

## 12. Final Output Rules

The standard final response must contain ONLY the Efficiency Dashboard visualization.

Do not append:
- A compliance summary.
- A results matrix.
- A stacked chart.
- A written report.
- A ranking.
- Additional visualizations.
- A generic final summary.

If an essential measurement is unavailable, show `N/A` in the dashboard.

If the evaluation fails entirely and no dashboard can be produced, provide a concise error message explaining what prevented the run.

Always prioritize accurate measurements, reproducibility, data security, and honest comparisons over making either evaluator appear better.
